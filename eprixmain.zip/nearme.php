<?php
if(isset($_GET['data']))
{
$data=json_decode($_GET['data']);
$userlat=$data->userlat;
$userlon=$data->userlon;
$longi=$data->longi;
$lat=$data->lat;
$data_send=array();
$dist=array();
for($i=0;$i<29;$i++)
   {
	   $apicall=file_get_contents("https://api.mapbox.com/directions/v5/mapbox/cycling/2.3090545,48.8531797;".$longi[$i].",".$lat[$i]."?steps=true&alternatives=true&access_token=pk.eyJ1IjoidW5pdGVkYnloY2wiLCJhIjoiY2oyMnU5aW50MDAxcTM0bzdrZWd6d2F2ayJ9.A35fLnzsn18JyajVXY3few"); 
	//    $apicall=file_get_contents("https://api.mapbox.com/directions/v5/mapbox/cycling/".$userlon.",".$userlat.";".$longi[$i].",".$lat[$i]."?steps=true&alternatives=true&access_token=pk.eyJ1IjoidW5pdGVkYnloY2wiLCJhIjoiY2oyMnU5aW50MDAxcTM0bzdrZWd6d2F2ayJ9.A35fLnzsn18JyajVXY3few"); 
	  $de=json_decode($apicall);
	  //$dist=array($i=>array(0=>$de->routes[0]->distanc,'lat'=>$lat[$i],'lng'=>$longi[$i]));
	  $dist[$i]['dist']=$de->routes[0]->distance;
	  $dist[$i]['lat']=$lat[$i];
	  $dist[$i]['lng']=$longi[$i];
	   
   }
   $length=29;
   for($i=0;$i<$length-1;$i++)
       {
		   $min=$i;
		   for($j=0;$j<$length;$j++)
		       {
				   if($dist[$j]['dist']<$dist[$i]['dist'])
				       {
						   $min=$j;
					   }
			   }
		   if($min!=$i)
		   		{
					//swap
					$temp_dist=$dist[$i]['dist'];
					$temp_lat=$dist[$i]['lat'];
					$temp_lng=$dist[$i]['lng'];
					$dist[$i]['dist']=$dist[$min]['dist'];
					$dist[$i]['lat']=$dist[$min]['lat'];
					$dist[$i]['lng']=$dist[$min]['lng'];
					$dist[$min]['dist']=$temp_dist;
					$dist[$min]['lat']=$temp_lat;
					$dist[$min]['lng']=$temp_lng;
				}
	   }
	   
	  		  
	   echo json_encode($dist);
}

	  						
	  
?>