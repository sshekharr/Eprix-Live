-- phpMyAdmin SQL Dump
-- version 4.0.10.18
-- https://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Oct 02, 2017 at 12:49 PM
-- Server version: 5.6.33-79.0-log
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `asgasmus_all_quadcoders_content`
--

-- --------------------------------------------------------

--
-- Table structure for table `tracking_members`
--

CREATE TABLE IF NOT EXISTS `tracking_members` (
  `id` int(254) NOT NULL AUTO_INCREMENT,
  `uniqid` text NOT NULL,
  `own_email_number` text NOT NULL,
  `friends` text NOT NULL,
  `own_lat` text NOT NULL,
  `own_lon` text NOT NULL,
  `count` int(254) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=50 ;

--
-- Dumping data for table `tracking_members`
--

INSERT INTO `tracking_members` (`id`, `uniqid`, `own_email_number`, `friends`, `own_lat`, `own_lon`, `count`) VALUES
(39, '5973581f06be2', 'rahul', 'shekhar', '22.488462', '88.2863647', 1),
(40, '59735889b4da5', 'shekhar', 'rahul', '22.4884619', '88.2863644', 1),
(41, '59749eb8acb6d', 'skahar203@gmail.com', 'rahulkahar10@gmail.com', '22.4938176', '88.3341316', 1),
(42, '59749edb96e0d', 'rahulkahar10@gmail.com', 'skahar203@gmail.com', '48.8570739', '2.2911826', 1),
(43, '5974a1247628b', 'rahulkahar10@gmail.com', 'skahar203@gmail.com', '48.8570739', '2.2911826', 1),
(44, '5974a24ac69ce', 'sskahar203@gmail.com', 'ssskahar203@gmail.com', '48.8570739', '2.2911826', 1),
(45, '5974a27a62f7a', 'ssskahar203@gmail.com', 'sskahar203@gmail.com', '48.8570739', '2.2911826', 1),
(46, '5974e4e25c523', 'sssskahar203@gmail.com', 'meenakahar9@gmail.com', '22.4884619', '88.2863665', 1),
(47, '5977b086c8919', 'sssssskahar203@gmail.com', 'ssssssskahar203@gmail.com', '22.4894105', '88.2952898', 1),
(48, '5977b09e1d3d7', 'ssssssskahar203@gmail.com', 'sssssskahar203@gmail.com', '48.8610543', '2.2989426', 1),
(49, '598094644e23e', 'fgjhfg', 'fgj', '12.9715987', '77.5945627', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
