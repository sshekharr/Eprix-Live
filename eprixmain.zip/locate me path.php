<?php
if(isset($_GET['data']))
{
$data=json_decode($_GET['data']);
$wroom_lat=$data->toilat;
$wroom_lng=$data->toilng;
$user_lat=$data->userlat;
$user_lng=$data->userlng;
$url="https://api.mapbox.com/directions/v5/mapbox/driving/".$user_lng.",".$user_lat.";".$wroom_lng.",".$wroom_lat."?overview=false&alternatives=true&steps=true&access_token=pk.eyJ1IjoidW5pdGVkYnloY2wiLCJhIjoiY2oyMnU5aW50MDAxcTM0bzdrZWd6d2F2ayJ9.A35fLnzsn18JyajVXY3few";
$url_fetch=file_get_contents($url);
$data_url=json_decode($url_fetch);
$i[]="";
$j=0;
foreach($data_url->routes as $data_)
{
	foreach($data_->legs as$data__)
	{
		foreach($data__->steps as $data___)
		{
			foreach($data___->intersections as $data____)
			     {
					 $i[$j++]="[".$data____->location[0].",   ". $data____->location[1]."],";
					 
				 }
	
		
		}
	}
		foreach($i as $d)
		   {
			   echo $d."<br>";
		   }
}
//echo $data_url->origin->type;

	
}
?>