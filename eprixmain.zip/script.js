// JavaScript Document
var num,tourcontain,tour__,tour_btn,map_content_hide=false;
$(document).ready(function(e) {
	
	
	//event
	$("#event").bind("click",function(){
		      event_();
		});
	if($.cookie("touropen")=='yes')
				{
					tour___();
				}
	
	//Time System
	$.ajax({
		type:'GET',
		dataType:"json",
		url:"https://script.googleusercontent.com/macros/echo?user_content_key=IXJHk1IeSauDLFuH2vw7C9QMtR1ZUM14KoxnzDASyr9dZtVa2hrgNOjrwqLyLQa5NTwqZDUbMXMFJk8vjVktC-AduBQHCTV4m5_BxDlH2jW0nuo2oDemN9CCS2h10ox_1xSncGQajx_ryfhECjZEnJ9GRkcRevgjTvo8Dc32iw_BLJPcPfRdVKhJT5HNzQuXEeN3QFwl2n0M6ZmO-h7C6bwVq0tbM60-YSRgvERRRx_Glx38N8iKHQ&lib=MwxUjRcLr2qLlnVOLh12wSNkqcO1Ikdrk",
		success: function(msg){
			var hour=msg.hours;
			var mint=msg.minutes;
			var second=msg.seconds;
			var mint_show;
			var sec, date,date1,date_show;
			date1=msg.fulldate;
			date=date1.split(" ");
			date_show=date[0] +' '+date[1]+' '+date[2]+' '+date[3];
			sec=second;
			if(mint<10)
			  {
				  mint_show= "0"+mint;
				  
			  }
			  else
			  {
				  mint_show=mint;
				  
			  }
			$(".hour").empty().html(hour+':');
			$(".min").empty().html(mint_show);
			$(".sec").empty();
			$(".date").empty().html(date_show);
			
		}
		
		});
   setInterval(function(){
	   $.ajax({
		type:'GET',
		dataType:"json",
		url:"https://script.googleusercontent.com/macros/echo?user_content_key=IXJHk1IeSauDLFuH2vw7C9QMtR1ZUM14KoxnzDASyr9dZtVa2hrgNOjrwqLyLQa5NTwqZDUbMXMFJk8vjVktC-AduBQHCTV4m5_BxDlH2jW0nuo2oDemN9CCS2h10ox_1xSncGQajx_ryfhECjZEnJ9GRkcRevgjTvo8Dc32iw_BLJPcPfRdVKhJT5HNzQuXEeN3QFwl2n0M6ZmO-h7C6bwVq0tbM60-YSRgvERRRx_Glx38N8iKHQ&lib=MwxUjRcLr2qLlnVOLh12wSNkqcO1Ikdrk",
		success: function(msg){
			var hour=msg.hours;
			var mint=msg.minutes;
			var second=msg.seconds;
			var mint_show;
			var sec, date,date1,date_show;
			date1=msg.fulldate;
			date=date1.split(" ");
			date_show=date[0] +' '+date[1]+' '+date[2]+' '+date[3];
			sec=second;
			if(mint<10)
			  {
				  mint_show= "0"+mint;
				  
			  }
			  else
			  {
				  mint_show=mint;
				  
			  }
			$(".hour").empty().html(hour+':');
			$(".min").empty().html(mint_show);
			$(".sec").empty();
			$(".date").empty().html(date_show);
			
		}
		
		});
	   },30000);
	   
	   //weather system
	   
	    var lat_ip,long_ip,lat_geo,long_geo,lat_weather,long_weather;
	  
		  if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition, error);
		         
   				 }
	 else { 
	        
			$.ajax({
		  type:'GET',
		  dataType:"json",
		  url:"http://ip-api.com/json",
		  success: function(msg){
			 lat_ip=msg.lat;
			 long_ip=msg.lon;
			 lat_weather=lat_ip;
			 long_weather=long_ip;
			 weather();
			 
		  				}
		  		}); 
    	        
    		}
	   function showPosition(position) {
						lat_geo= position.coords.latitude;
						long_geo=position.coords.longitude;
						lat_weather=lat_geo;
						long_weather=long_geo;
						weather();
	
	  				 }
    function error(er){
		if(er.PERMISSION_DENIED||er.POSITION_UNAVAILABLE||er.TIMEOUT||er.UNKNOWN_ERROR||er.PositionError)
										{
													$.ajax({
														  type:'GET',
														  dataType:"json",
														  url:"http://ip-api.com/json",
														  success: function(msg){
															 lat_ip=msg.lat;
															 long_ip=msg.lon;
															 lat_weather=lat_ip;
															 long_weather=long_ip;
															 weather();
																  
																		}
																}); 
										}
						
						}
						
						function weather()
			{
							$.ajax({
										type:'GET',
										url:"http://api.openweathermap.org/data/2.5/weather?lat="+lat_weather+"&lon="+long_weather+"&appid=e4c4f74eb4fba14735b67b5eeca7df7e",
										dataType:"json",
										success: function(msg){
											var icon=msg.weather[0].icon;
											var title=msg.weather[0].description;
											if(icon=='50d'||icon=='50n')
													{
														$(".weather_icon").addClass("wi-windy");
														$(".weather_icon").attr("title",title);
													}
											if(icon=='13d'||icon=='13n')
													{
														$(".weather_icon").addClass("wi-day-snow");
														$(".weather_icon").attr("title",title);
													}	
											if(icon=='11d'||icon=='11n')
													{
														$(".weather_icon").addClass("wi-thunderstorm");
														$(".weather_icon").attr("title",title);
													}	
											if(icon=='10d')
													{
														$(".weather_icon").addClass("wi-day-rain");
														$(".weather_icon").attr("title",title);
													}
											if(icon=='10n')
													{
														$(".weather_icon").addClass("wi-night-rain");
														$(".weather_icon").attr("title",title);
													}
											if(icon=='09d'||icon=='09n')
													{
														$(".weather_icon").addClass("wi-rain-mix");
														$(".weather_icon").attr("title",title);
													}	
											if(icon=='04d'||icon=='04n')
													{
														$(".weather_icon").addClass("wi-cloudy");
														$(".weather_icon").attr("title",title);
													}
											if(icon=='03d'||icon=='03n')
													{
														$(".weather_icon").addClass("wi-cloud");
														$(".weather_icon").attr("title",title);
													}	
											if(icon=='02n')
													{
														$(".weather_icon").addClass("wi-night-cloudy");
														$(".weather_icon").attr("title",title);
													}
											if(icon=='02d')
													{
														$(".weather_icon").addClass("wi-day-cloudy");
														$(".weather_icon").attr("title",title);
													}
											if(icon=='01d')
													{
														$(".weather_icon").addClass("wi-day-sunny");
														$(".weather_icon").attr("title",title);
													}
											if(icon=='01n')
													{
														$(".weather_icon").addClass("wi-night-clear");
														$(".weather_icon").attr("title",title);
													}	
										}
										
									});
				
				}			
	
			
			
			
			
			$(".click").mbClicker({
				size: 120, //Maximum size of circle
				speed: 250, //Time of animation in miliseconds
				colour: 'rgba(0,0,0,0.25)', //Colour of circle and shadow
				shadow: false, //Whether or not to have a shadow on the circle
				buttonAnimation: true //Only use if button doesn't have a style attribute
		});
		
		//search
	$("#search_txt").bind("focusin",function(){search_open();});
	$("#search_close").bind("click",function(){search_close();});
	$("#search_txt").bind("focusin",function(){searchFocusIn();});
	$("#search_txt").bind("focusout",function(){searchFocusOut();});
	//track frnd
	$("#track_frnd").bind("click",function(){trackfrnd()});
	$("#track_close").bind("click",function(){track_closed();});
	$("#track_main_no").bind("keyup",function(){take_mem_number()});
	$("#track_close_btn_block").bind("click",function(){close_block_track()});
	
	

						
});

function tour___() {
				minimize();
				$(".search_close").css("display","block");
				 tour__=$(".tour_tutor");
				tour__.css("display","block");
				var first=$("#num").attr("val");
				if($.cookie('tourpage')==7)
				   {
					   tourcontain=tour__.html();
					   tour__.empty().html(' <center><!--Tour end msg--><div class="end_tour"><div class="end_tour_msg_header">Message</div><div class="alert_icon"><img src="icon_content/warning.png" width="80" height="80"></div><div id="end_tour_msg">If You Want To Take a Tour Again Then Click "YES" </div><div class="btn_lower_part"></div><div class="conform_btn"><div class="tour_next_btn right" id="next" onClick="start()">YES<div class="btn_lower_part"></div></div><!--End of the button--><div class="tour_next_btn right click" id="next" onClick="close_()">NO<div class="btn_lower_part"></div></div><!--End of the button--></div></div></center>');
					   
					   
				   }
				 else{
					   
				$.cookie('tourpage', first);
				 }
            }
			
			
//tour next
function next(){
	
	 num=$.cookie('tourpage');
	 
	 if(num>=7)
				   {
					   tourcontain=tour__.html();
					   tour__.empty().html(' <center><!--Tour end msg--><div class="end_tour"><div class="end_tour_msg_header">Massage</div><div class="alert_icon"><img src="icon_content/warning.png" width="80" height="80"></div><div id="end_tour_msg">If You Want To Take a Tour Again Then Click "YES" </div><div class="btn_lower_part"></div><div class="conform_btn"><div class="tour_next_btn right" id="next" onClick="start()">YES<div class="btn_lower_part"></div></div><!--End of the button--><div class="tour_next_btn right click" id="next" onClick="close_()">NO<div class="btn_lower_part"></div></div><!--End of the button--></div></div></center>');
					   
					   
				   }
				   
		else{
	
				$("."+num).css("display","none");
				 num=((num*1)+1);
				$.cookie('tourpage', num);
				$("."+num).css("display","block");
				console.log(num);
		     }
	
	    	
	
}
function start(){
	$.removeCookie("tourpage");
		location.reload();
		tour___();
		$.cookie("touropen","yes");
}
//close tour
function close_(){
	$(".tour_tutor").css("display","none");
	try {
	$.removeCookie("touropen");
	}
	catch(err)
	  {console.log(err);} 
	$(".search_close").css("display","none");
	}
	function event_(){
		
		var content=$("#content");
		if(map_content_hide==true)
		   {
			   content.fadeIn('fast');
			   map_content_hide=false;
		   }
		   else
		     {
				 map_content_hide=true;
				 content.fadeOut('fast');
			 }
	}
//search open
function search_open(){
	$("#search__back").fadeIn("fast");
	$(".search_result").css("display","block");
	$(".search_close").css("display","block");
	
}
//search focusIn
function searchFocusIn(){
	$("#search_txt").animate({width:'60%'});
	$("#search_txt").animate({marginLeft:'10%'});
	focus_();
	$("#search_txt").attr("placeholder","SEARCH");
}
//search close
function search_close(){
	$("#search__back").fadeOut("fast");
	$(".search_result").css("display","none");
	$(".search_close").css("display","none");
	
}
//search focusOut
function searchFocusOut(){
	$("#search_txt").animate({width:'35%'});
	$("#search_txt").animate({marginLeft:'12%'});
	focus_out();
	setTimeout(function(){$("#search_txt").attr("placeholder","");},800);
}
	
	
//search text animation
//focus In
function focus_(){
	$("#search_title").animate({marginTop:'6%'});
}
//focus out
function focus_out(){
	setTimeout(function(){$("#search_title").animate({marginTop:'9%'});},500);
	$("#search_txt").val('');
	$.cookie("opensearch",0);
}
//track friend
function trackfrnd(){
	minimize();
	if($.cookie('userid_true')==1)
		{
			$("#track_main_no").attr("disabled","disabled");
			$("#track_main_no").val('You have already update your buddy Tracking List.');
				$("#track_main_no").blur();
		}
	$("#track_back").fadeIn("fast");
	$("#search_title").fadeOut("fast");
	$("#search_txt").fadeOut("fast");
	$("#track_main_no").focus();
}
//track closed
function track_closed(){
	$("#track_back").fadeOut("fast");
	$("#search_title").fadeIn("fast");
	$("#search_txt").fadeIn("fast");
	$("#track_main_no").val('');
	$("#tracker_number_continer").empty();
}
//check and track number
function take_mem_number(){
	var totalmem=$("#track_main_no").val()
	if(!$.isNumeric(totalmem)||$.trim(totalmem).length==0)
		{
			$("#track_main_no").val('');
			$("#tracker_number_continer").empty();
		}
	if($.isNumeric(totalmem)&&totalmem<=25)
	    {
			$("#tracker_number_continer").empty();
			for(var i=0;i<totalmem;i++)
				{
					$("#tracker_number_continer").append('<input type="text" id="track_main_no_'+i+'" class="track_main_box number_" placeholder="Enter the email of member '+(i+1)+'">');
				}
					if($.trim(totalmem).length!=0&&totalmem>0)
							{
							$("#tracker_number_continer").append('<center><div class="tour_next_btn click tour_next_btn_right" id="upload_tracking_data" onClick="upload_location()">Upload Data<div class="btn_lower_part"></div></div><center><img src="icon_content/loading (1)-min.gif" width="110" height="110" id="upload_tracking_loading" style="display:none; cursor:pointer; margin-top:15px;"></center></center>');
							 $("#track_main_no_0").attr("placeholder","Enter your email id");
							}
		}
	if(totalmem>25)
	   {
		   toastr.error('You reached the maximum number(25) ! ');
	   }
}
//upload location
function upload_location(){
	   if($.cookie('userid_true')!=1)
			{
				var totalmember=$("#track_main_no").val(),members=[],mem1_lat,mem1_lon;
							for(var i=0;i<totalmember;i++)	
							{
								var mem_num=$("#track_main_no_"+i).val();
								if(mem_num.length!=0&&$.trim(mem_num).length!=0)
								   {
										members.push(mem_num);
										console.log(members);
										$("#track_main_no_"+i).css("border-bottom-color","#fff");
										
								   }
								else
								   {
									   members=[];
									   toastr.error('field '+(i+1)+' is empty.');
									   console.log(members);
									   $("#track_main_no_"+i).css("border-bottom-color","#f33");
								   }
								   
								
							}
					if(totalmember==members.length)
							{
								data={'members':members,'mem1_lat':lat_weather,'mem1_lon':long_weather};
								data=JSON.stringify(data);
								$.ajax({
									type:'GET',
									data:{data:data},
									dataType:"json",
									url:"track.php",
									beforeSend: function()
										 {
											 $("#upload_tracking_loading").css("display","block");
											 $("#upload_tracking_data").css("display","none");
											 
										 },
									success: function(msg){
										if(msg=='error in upload data')
												{
													toastr.error('Error in uploading data.');
												}
										else
											  {
												  var userid=msg.split('.-');
												  userid=userid[1];
												  $.cookie('userid',userid);
												  $.cookie('userid_true',1);
												  $("#upload_tracking_loading").css("display","none");
												  $("#upload_tracking_data").attr('onClick','').empty().html('Updated <div class="btn_lower_part"></div>').css("display","block");
											  }
										
									}
			
									
									
									});
							}
			}
		
		else
		    {
				$('#block_track').fadeIn('fast');
				$("#track_main_no").blur();
				
			}
				
}

	//updating lat-lon
setInterval(function(){
	if($.cookie('userid'))
		{
			if (navigator.geolocation) {
				navigator.geolocation.getCurrentPosition(showPosition);
			}
				function showPosition(position) {
								var userid=$.cookie('userid');
								var data={'lat':position.coords.latitude,'lon':position.coords.longitude,'id':userid}
								data=JSON.stringify(data);
								$.ajax({
									type:'GET',
									url:"track.php",
									data:{location:data},
									dataType:"json",
									success: function(msg){
										console.log(msg);
									}
									
									});
			
							 }
		}
	},50000);

	//close block track
	function close_block_track(){
		$("#block_track").fadeOut('fast');
		track_closed();
	}