<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Eprix</title>
<link href="toastr.min.css" rel="stylesheet" type="text/css">
<link href="style.css" rel="stylesheet" type="text/css" id="stylesheet_1">
<link href='https://api.mapbox.com/mapbox.js/v3.1.0/mapbox.css' rel='stylesheet' />
<link rel="stylesheet" href="leaflet.css"/>
<link href="leaflet-routing-machine.css" rel="stylesheet" type="text/css">
<script src="annyang.min.js"></script>
</head>
<body onLoad="onload">
<div class="back">
<img src="icon_content/backmain-min.png" class="img">
</div>
<div class="full" id="full">
 
                 <!--AI INTREGATION-->
                 <div class="ai" id="ai"><center><img src="icon_content/microphone (1).png" width="50" height="50" id="ai_img"></center></div>
 				<div class="left_menu"><!--Start of the left Menu-->
                <div class="left_menu_contain" id="home"><img src="icon_content/home-icon-silhouette_.png" class="menu_left_icon_home"><div class="glass_dark"><div 	class="menu_txt">Home</div></div></div>
								<div class="left_menu_contain" id="races_s"><img src="icon_content/RACES ICON.png" class="menu_left_icon"><div class="glass_dark"><div 	class="menu_txt">Races</div></div></div>
							<div class="left_menu_contain"><img src="icon_content/TICKET ICON.png" class="menu_left_icon ticket"><div class="glass_dark">							<div class="menu_txt menu_txt_tss">tickets</div></div></div>
							<div class="left_menu_contain" id="event"><img src="icon_content/fireworks-on-event-day-reminder-calendar-page-of-interface.png" class="menu_left_icon stream"><div class="glass_dark"><div class="menu_txt menu_txt_tss"style=" line-height:80px">Event</div></div></div>
							<div class="left_menu_contain" id="tour_button" onClick="tour___()"><img src="icon_content/QUICK TOUR ICON.png" class="menu_left_icon tour"><div class="glass_dark"><div class="menu_txt menu_txt_tour"style="line-height:80px;">tour</div></div></div>
                            <div class="left_menu_contain" id="track_frnd" class="search_btn" title="track friend"><img src="icon_content/tracking-map.png" class="menu_left_icon search"><div class="glass_dark"><div class="menu_txt menu_txt_tss">Track</div></div></div>
				</div>
                 <!--End of the Left Menu-->
                 <!--Start of the the map menu-->
                 <div id="content" class="content">
                 <div class="map_live_feed_div">
                 		<div class="map">
                        <div class="map_in">
                 				<div class="map_inside">
                             <div class="real_map" id="real_map" style="width:100%; height:100%; display:none;">
                             </div>
                             <div class="loading_map" id="loading_map" style="z-index:99999999"></div>
                                </div>
                                
                                <div class="left_bar_map">
                                		<div class="map_bar_icon">
                                        <center>
                                        <img src="icon_content/TICKET ICON.png" width="16" height="16" class="icon_padding"><br>
                                        <img src="icon_content/FOOD ICON.png" width="16" height="16" class="icon_padding"><br>
                                        <img src="icon_content/WASHROOM ICON.png" width="16" height="16" class="icon_padding"><br>
                                        <img src="icon_content/EXIT ICON.png" width="16" height="16" class="icon_padding"><br>
                                        <img src="icon_content/LOCATION ICON.png" width="16" height="16" class="icon_padding">
                                        <div class="map_txt">paris track</div>
                                        </center>
                                        </div>
                                
                                </div>
                                <div class="seat_finder" id="seat_finder">
                                
                                <div class="expand" id="expand">
                                <img src="icon_content/EXPAND ICON.png" width="20" height="20" class="expand_icon">
                                <img src="icon_content/dEXPAND ICON copy-min.png" width="20" height="20" class="minimize_icon">
                                </div>
                                </div>
                         </div>
                 		</div>
                        <!--Start of the map menu-->
                        <div class="map_menu" id="map_menu">
                        		<div id="toilet" class="toilet width200">
                                <center>
                                <img src="icon_content/men-and-women-toilet.png" width="50" height="50" class="center">
                                </center>
                                <div id="toilets" class="menutext"><center><div class="menu_inner_txt">Toilets</div></center></div>
                                <div id="nearu" class="menutext"><center><div class="menu_inner_txt">Near Me</div></center></div>
                                </div>
                                <div id="resturant" class="resturant width200" style="width:210px;">
                                <center>
                                <img src="icon_content/restaurant-cutlery-circular-symbol-of-a-spoon-and-a-fork-in-a-circle.png" width="50" height="50" class="center">
                                </center>
                                <div id="ct" class="menutext"><center><div class="menu_inner_txt" style="margin-top:80%">   c&t </div></center></div>
                                <div id="crew" class="menutext"><center><div class="menu_inner_txt" style="margin-top:80%">Crew</div></center></div>
                                 <div id="foodbev" class="menutext"><center><div class="menu_inner_txt" style="font-size:12px; margin-top:75%;">Food & Bev</div></center></div>
                                </div>
                                <div id="medicalcenter" class="medicalcenter width200">
                                 <center>
                                <img src="icon_content/medical-kit.png" width="50" height="50" class="center">
                                </center>
                                <div id="hospitalities" class="menutext"><center><div class="menu_inner_txt" style="font-size:12px">hospital</div></center></div>
                                <div id="medicalcenter" class="menutext"><center><div class="menu_inner_txt" style="font-size:12px; margin-top:50%;">medical center</div></center></div>
                                </div>
                                <div id="emergencyexit" class="emergencyexit width200" style="width:130px;">
                                <center>
                                <img src="icon_content/emergency-exit.png" width="50" height="50" class="center">
                                </center>
                                <div id="exit" class="menutext"><center><div class="menu_inner_txt" style="margin-top:35%; font-size:11px">Emergency exit</div></center></div>
                                </div>
                                <div id="vipareas" class="vipareas width200" style="width:130px;">
                                <center>
                                <img src="icon_content/steps.png" width="50" height="50" class="center">
                                </center>
                                <div id="grand_stand" class="menutext"><center><div class="menu_inner_txt" style="margin-top:40%;">Grand-<br>stand</div></center></div>
                                </div>
                        	</div>
                            <!--End of the map menu-->
                        <div class="live_feed">
                        <div class="feed_header">live feed</div>
                        <div class="feed">
                        <div class="online_feed"></div>
                        <div class="online_feed"></div>
                        <div class="online_feed"></div>
                        <div class="online_feed"></div>
                        <div class="online_feed"></div>
                        <div class="online_feed"></div>
                        </div>
                        </div>
                 </div>
                 
                 </div>
                 <!--End of the the Map menu-->
                 <!--Start of the the live feed menu-->
                 
                 <!--End of the the live feed menu-->
                  <!--Start of the the bottot menu-->
     <div class="bottom_menu">
     	<div class="bottom_menu_inner">
                    <div class="raceh"><img src="icon_content/RACER ICON.png" class="raceh_icon"></div>
                    <div class="group"><img src="icon_content/TEAM ICON copy-min.png" class="raceh_icon"></div>
                    <div class="social"><img src="icon_content/SOCIAL ICON.png" class="social_icon"></div>
                    <div class="hot"><img src="icon_content/HOT NEWS MENU.png" class="raceh_icon"></div>
                    <div class="fanBoast"><img src="icon_content/logo-fanboost-min.png" class="fanBoast_icon"></div>
    	 </div>
         	<div class="logo"><img src="icon_content/FORMULA E WHITE ICON.png" class="logo_icon"></div>
            <div class="time_weather">
            		<div class="time" id="time">
                    <h1 class="hour">00:</h1>
                    <h1 class="min">00</h1>
                    <h1 class="sec">:00</h1>
                    <div class="date"></div>
                    </div>
                    <div class="weather" id="date">
                    <center><i class="weather_icon" title="" id="weather_icon"></i></center>
                    </div>
            </div>
     </div> 
     <!--End of the the bottot menu-->          
<div class="tour_tutor"><!--start of the tour-->
<div id="" class="search_close" style="z-index:9999999999"><img src="icon_content/error.png" width="50" height="50" onClick="close_();"style="z-index:9999999999"></div>
<div class="data_arrow_cointainer">
			<div id="num" val="0" class="0 num"><!--RACES-->
		<div class="arrow"><img src="icon_content/upper.png" width="150" height="50"></div>
        <div class="tutor_txt"><p>In this section you will again come back to your home screen.</p></div>
        	<div class="tour_next_btn click" id="next" onClick="next()">NEXT
                 <div class="btn_lower_part"></div>
            </div>
        </div>
        		<div id="num" val="1" class="1 num" style="position:absolute; top:135px; display:none"><!--TICKET-->
		<div class="arrow"><img src="icon_content/upper.png" width="150" height="50"></div>
        <div class="tutor_txt"><p>In this section you will see race schedules and live report of race.</p></div>
        	<div class="tour_next_btn click" id="next" onClick="next()">NEXT
                 <div class="btn_lower_part"></div>
            </div>
        </div>
        
        		<div id="num" val="2" class="2 num" style="position:absolute; top:230px; display:none"><!--STREAM-->
		<div class="arrow"><img src="icon_content/upper.png" width="150" height="50"></div>
        <div class="tutor_txt"><p>In this section you wiil able to book your ticket for race.</p></div>
        	<div class="tour_next_btn click" id="next" onClick="next()">NEXT
                 <div class="btn_lower_part"></div>
            </div><!--End of the button-->
        </div>
        		<div id="num" val="3" class="3 num" style="position:absolute; top:200px; display:none"><!--Search-->
        <div class="tutor_txt"><p>In this section you will able to know about whats event happening before and after race with event(eVillage) name and timing.</p></div>
        	<div class="tour_next_btn click" id="next" onClick="next()">NEXT
                 <div class="btn_lower_part"></div>
            </div><!--End of the button-->
            <div class="arrow" style="margin-top:-50px;"><img src="icon_content/repeat_down.png" width="150" height="50"></div>
        </div>
        
        		<div id="num" val="4" class="4 num" style="position:absolute; top:370px; display:none"><!--TOUR-->
        <div class="tutor_txt"><p>This section helps you to how to use this website easily.</p></div>
        	<div class="tour_next_btn click" id="next" onClick="next()">NEXT
                 <div class="btn_lower_part"></div>
            </div><!--End of the button-->
            <div class="arrow" style="margin-top:-50px;"><img src="icon_content/repeat_down.png" width="150" height="50"></div>
        </div>
        <div id="num" val="5" class="5 num" style="position:absolute; top:450px; display:none"><!--TOUR-->
        <div class="tutor_txt"><p>This section helps you to track your friends in the race if He/She is lost.</p></div>
        	<div class="tour_next_btn click" id="next" onClick="next()">NEXT
                 <div class="btn_lower_part"></div>
            </div><!--End of the button-->
            <div class="arrow" style="margin-top:-50px;"><img src="icon_content/repeat_down.png" width="150" height="50"></div>
        </div>
       <div id="num" val="6" class="6 right_side" style="display:none; float:right; margin-right:420px; margin-top:255px;"><!--MAP-->
       <div class="arrow" style=" margin-right:-70px; float:right;"><img src="icon_content/repeat_rightside.png" width="150" height="50"></div>
        <div class="tutor_txt_right"><p>On Tap this button you able to find washrooms,medical center, resturant ect.</p></div>
        	<div class="tour_next_btn click tour_next_btn_right" id="next" onClick="next()">NEXT
                 <div class="btn_lower_part"></div>
            </div><!--End of the button-->
            
        </div>
        		 </div>
       <div id="num" val="7" class="7 right_side" style="display:none; float:right; margin-right:420px; margin-top:355px;"><!--LIVE FEED-->
       <div class="arrow" style=" margin-right:-70px; float:right;"><img src="icon_content/repeat_rightside.png" width="150" height="50"></div>
        <div class="tutor_txt_right"><p>This part give you live feed about race.</p></div>
        	<div class="tour_next_btn click tour_next_btn_right" id="next" onClick="close_()">CLOSE
                 <div class="btn_lower_part"></div>
            </div><!--End of the button-->
            
        </div>
       
</div>
<!--search-->
<div id="search__back" class="search__"></div>
<div id="" class="search_close"><img src="icon_content/error.png" width="50" height="50" id="search_close"></div>
<div class="search_title" id="search_title">SEARCH</div>
<input type="text" id="search_txt" class="search_txt_box" >
<div id="search_result" class="search_result"></div>
<!--search End-->
</div><!--End of the tour-->
<!--track friend-->
<div class="track_back" id="track_back">
<div id="track_close" class="track_close"><img src="icon_content/error.png" width="50" height="50" id="track_close_btn"></div>
<center>
<div class="tour_next_btn click tour_next_btn_right width__" id="next" onClick="track_in_map()">Find Your friends in map
                 <div class="btn_lower_part"></div>
            </div><br>
            <div style="color:#fff; font-family:uhcl; font-size:12px;">*You and your friends have to give their friends members email/phone from their individual phone. In order to track your friends</div>
<input type="tel" id="track_main_no" class="track_main_box" placeholder="total number of member came to see race">
<div id="tracker_number_continer" class="tracker_number_continer"></div>
</center>
<div id="block_track" class="block_track"><div id="track_close" class="track_close"><img src="icon_content/error.png" width="50" height="50" id="track_close_btn_block"></div><center><div class="block_track_txt">You have already update your buddy Tracking List.</div></center></div>
</div>
<!--end of the track friend-->
</div>
<script src="jquery-3.2.1.min.js"></script>
<script src="mbclicker.js"></script>
<script src="jquery.cookie.js"></script>
<script src="script.js"></script>
<script src="leaflet.js"></script>
<script src='https://api.mapbox.com/mapbox.js/v3.1.0/mapbox.standalone.js'></script>
<script src="leaflet-routing-machine.min.js"></script>
<script src="map.js"></script>
<script src="ai.js"></script>
<script src="toastr.js"></script>
</body>
</html>