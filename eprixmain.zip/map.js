// JavaScript Document
var marker=[],you,nearme_lat=[],nearme_lng=[],map,toiletIcon;
var lat_ip,long_ip,lat_geo,long_geo,lat_weather,long_weather,route,yes=false,nearme_=false,src;
L.mapbox.accessToken = 'pk.eyJ1IjoidW5pdGVkYnloY2wiLCJhIjoiY2oyMnU5aW50MDAxcTM0bzdrZWd6d2F2ayJ9.A35fLnzsn18JyajVXY3few';
var Lat=[48.8607935,48.8607073,48.8606648,48.8604382,48.8595946,48.8596485,48.8592884,48.8592708,48.8584889,48.8585614,48.8585786,48.8583419,48.8585432,48.8579326,48.8571965,48.8556653,48.8541198,48.8538357,48.8531797,48.8536052,48.8540239,48.8536528,48.8535163,48.8535230,48.8545376,48.8551009,48.8551791,48.8550269,48.8559281];
		
		var Lon=[2.3145848,2.3146847,2.3146788,2.3144016,2.3144185,2.3141352,2.3143939,2.3142024,2.3139695,2.3139782,2.3140328,2.3119392,2.3119567,2.3098521,2.3101329,2.3096114,2.3096500,2.3096199,2.3090545,2.3113820,2.3120297,2.3139011,2.3145969,2.3148813,2.3149631,2.3162129,2.3162360,2.3164723,2.3148422],i;
		
$(document).ready(function(e) {
	$(".leaflet-marker-icon").click(function(e) {
          src= $("#mapicon").attr("iconsrc");
    });
	
	$(".expand_icon").click(function(e) {
       expand();
		  
    });
		$(".minimize_icon").click(function(e) {
            minimize();
		});
		
		
		 map = L.mapbox.map('real_map').setView([48.855161, 2.313808], 15.48);
		
		
		
    				
L.mapbox.styleLayer('mapbox://styles/unitedbyhcl/cj2ww2nti000g2rmmlubzlmla').addTo(map);

//Washroom
$("#toilets").click(function(e) {
	
	toilet_pointers();
});

$("#nearu").click(function(e) {
	near_me_toilets();
});

//route
$.ajax({
	type:'GET',
	url:"route.php",
	data:{},
	success: function(msg){
		
	}
	
	});
	
	if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition, error);
		         
   				 }
	function showPosition(position) {
						lat_geo= position.coords.latitude;
						long_geo=position.coords.longitude;
						lat_weather=lat_geo;
						long_weather=long_geo;
						var meIcon = L.icon({
								iconUrl: 'icon_content/pin.png',
								iconSize:     [38,40],
								iconAnchor:   [22, 39], // size of the icon
								
							});
						you=L.marker([lat_weather, long_weather], {icon: meIcon}).addTo(map);
						console.log(long_weather+","+lat_weather);
	
	  				 }
	function error(er){
		if(er.PERMISSION_DENIED||er.POSITION_UNAVAILABLE||er.TIMEOUT||er.UNKNOWN_ERROR||er.PositionError)
										{
																		
													alert("Please Allow The Location For navigation.");
										}
						
						}


//food
$("#ct").click(function() {
    if(nearme_==false)
		{
			removeroute();
			removemarker();
			restIcon = L.icon({
						iconUrl: 'icon_content/rest-min-copy.png',
						iconSize:     [30,30], // size of the icon
											});
											
											marker[0]=L.marker([48.860636, 2.314382], {icon: restIcon}).addTo(map).bindPopup('<center><img src="icon_content/restaurant-cutlery-circular-symbol-of-a-spoon-and-a-fork-in-a-circle.png"  width="80" height="80" lat="48.860636" lng="2.314382" id="mapicon" iconsrc="icon_content/restaurant-cutlery-circular-symbol-of-a-spoon-and-a-fork-in-a-circle.png"/><br><br><button onclick="lme()" class="btn_locate">Locate Me</button></center>');
											
					
		}
		else
 {
	 alert("HoldOn!! Let me complete this work first. ");
 }
});
//crew	
$("#crew").click(function(e) {
     if(nearme_==false)
		{
			removeroute();
			removemarker();
			restIcon = L.icon({
						iconUrl: 'icon_content/rest-min-copy.png',
						iconSize:     [30,30], // size of the icon
											});
											
											marker[0]=L.marker([48.860806, 2.314288], {icon: restIcon}).addTo(map).bindPopup('<center><img src="icon_content/restaurant-cutlery-circular-symbol-of-a-spoon-and-a-fork-in-a-circle.png"  width="80" height="80" lat="48.860806" lng="2.314288" id="mapicon" iconsrc="icon_content/restaurant-cutlery-circular-symbol-of-a-spoon-and-a-fork-in-a-circle.png"/><br><br><button onclick="lme()" class="btn_locate">Locate Me</button></center>');
					
		}
		else
 {
	 alert("HoldOn!! Let me complete this work first. ");
 }
});	
$("#foodbev").click(function(e) {
    if(nearme_==false)
		{
			removeroute();
			removemarker();
			restIcon = L.icon({
						iconUrl: 'icon_content/rest-min-copy.png',
						iconSize:     [30,30], // size of the icon
											});
											
											marker[0]=L.marker([48.8608529, 2.3143221], {icon: restIcon}).addTo(map).bindPopup('<center><img src="icon_content/restaurant-cutlery-circular-symbol-of-a-spoon-and-a-fork-in-a-circle.png"  width="80" height="80" lat="48.8608529" lng="2.3143221" id="mapicon" iconsrc="icon_content/restaurant-cutlery-circular-symbol-of-a-spoon-and-a-fork-in-a-circle.png" iconsrc=""/><br><br><button onclick="lme()" class="btn_locate">Locate Me</button></center>');
					
		}
		else
 {
	 alert("HoldOn!! Let me complete this work first. ");
 }
});	

   			

});

//function()
function lme()
   {
	  removeroute(); 
	  var lat= $("#mapicon").attr("lat");
	  var lng= $("#mapicon").attr("lng");
	 
	  route_dis(lat, lng);
	   removemarker();
	   marker[i]=L.marker([lat, lng]).addTo(map);
	   
	   //fetching path
	   /*var data={"userlat":lat_weather,"userlng":long_weather,"toilat":lat,"toilng":lng};
	   data=JSON.stringify(data);
	   $.ajax({
		   type:'GET',
		   data:{data:data},
		   dataType:"json",
		   url:"locate me path.php",
		   beforeSend: function(){
						$("#loading_map").css("display","block");
					},
		   success: function(msg){
			   $("#loading_map").css("display","none");
			   
		   }
		   
		   });*/
		   
  
	   
   }
   
   function removemarker()
       {
		   
		   for(i=0;i<marker.length;i++) {
    map.removeLayer(marker[i]);
    }
	   }
	   
	   //route
	   function route_dis(lat, lng)
	      {
		  route= L.Routing.control({
		  waypoints: [
			L.latLng(lat_weather, long_weather),
			L.latLng(lat, lng)
		  ],
		  router: L.Routing.mapbox(L.mapbox.accessToken)
}).addTo(map);

yes=true;
	 
		  }
		  
		  function removeroute()
		       {
				   if(yes==true)
	    {
			route.getPlan().setWaypoints([]);
			yes=false;
			$(".leaflet-top").find(".leaflet-routing-container").removeClass("leaflet-routing-container");
		}
			   }
			   
function expand(){
						$(".map_in").addClass("width");
							$(".map_in").animate({height:"450px"});
						   $(".seat_finder").addClass("tok");
						   $("#expand").css("margin-left","1.2%");
						   $(".live_feed").fadeOut("slow");
						   $(".left_bar_map").addClass("height");
						   $('.expand_icon').css("display","none");
						   $(".minimize_icon").css("display","block");
						   $(".map_inside").css("background","none");
						   $("#real_map").css("display","block");
							$(".map_inside").addClass("height_mapinside");
						  setTimeout(function(){ map.invalidateSize()}, 2000);
							 $("#map_menu").fadeIn(800);
							 $("#ai").fadeOut('fast');
							 $("#search_txt").fadeOut("fast");
							 $(".search_title").fadeOut("fast");
					}
function minimize(){
							$(".map_in").removeClass("width");
							$(".map_in").animate({height:"250px"});
							$(".seat_finder").removeClass("tok");
							$("#expand").css("margin-left","2.7%");
							 $(".live_feed").fadeIn("slow");
							 $(".left_bar_map").removeClass("height");
							 $('.minimize_icon').css("display","none");
							 $(".expand_icon").css("display","block");
							 $(".map_inside").css("display","block");
							 $("#real_map").css("display","none");
							 $(".map_inside").removeClass("height_mapinside");
							 $(".map_inside").css("background","url(icon_content/Screen%20Shot%202017-05-13%20at%202.39.22%20PM.png)");
							 $("#map_menu").fadeOut(800);
							 $("#ai").fadeIn('fast');
							 $("#search_txt").fadeIn("fast");
							 $(".search_title").fadeIn("fast");
				}
//toilets
function toilet_pointers(){
					if(nearme_==false)
				 {
					removeroute();
					removemarker();
					toiletIcon = L.icon({
					iconUrl: 'icon_content/toilet-min.png',
					iconSize:     [30,30], // size of the icon
					
					
										});
				for(i=0;i<Lon.length;i++)
					 {
						 marker[i]=L.marker([Lat[i], Lon[i]], {icon: toiletIcon}).addTo(map).bindPopup('<center><img src="icon_content/men-and-women-toilet.png"  width="80" height="80" lat="'+Lat[i]+'" lng="'+Lon[i]+'" id="mapicon" iconsrc="icon_content/men-and-women-toilet.png"/><br><br><button onclick="lme()" class="btn_locate">Locate Me</button></center>');
						 
					 }
				 }
				 else
				 {
					 alert("HoldOn!! Let me complete this work first. ");
				 }
}
//near me
function near_me_toilets(){
	removeroute();
	nearme_=true;
    var data={"userlat":lat_weather,"userlon":long_weather,"longi":Lon, "lat":Lat};
	data=JSON.stringify(data);
	removemarker();
	$.ajax({
		    type:'GET',
			url:"nearme.php",
			dataType:"json",
			data:{data:data},
			beforeSend: function(){
						$("#loading_map").css("display","block");
					},
			success: function(data){
				$("#loading_map").css("display","none");
				$.each(data,function(index, element) {
					console.log(element.lng+","+element.lat);
					nearme_lat.push(element.lat);
					nearme_lng.push(element.lng);
					nearme_=false;
					
				});
						toiletIcon = L.icon({
						iconUrl: 'icon_content/toilet-min.png',
						iconSize:     [30,30], // size of the icon
						
											});
				for(i=0;i<5;i++)
					{
						marker[i]=L.marker([nearme_lat[i], nearme_lng[i]], {icon: toiletIcon}).addTo(map).bindPopup('<center><img src="icon_content/men-and-women-toilet.png"  width="80" height="80" lat="'+nearme_lat[i]+'" lng="'+nearme_lng[i]+'" id="mapicon" iconsrc="icon_content/men-and-women-toilet.png"/><br><br><button onclick="lme()" class="btn_locate">Locate Me</button></center>');
					}
				
			}
		
		});
}
//showing friends in map
function track_in_map(){
	var userid=$.cookie('userid');
	if($.cookie('userid_true')==1){
		data={'userid':userid};
		data=JSON.stringify(data);
	$.ajax({
				type:'GET',
				url:"track.php",
				dataType:"json",
				data:{data_userid:data},
				beforeSend: function(){
						$("#loading_map").css("display","block");
						track_closed();
						expand();
						removeroute();
						removemarker();
						map.removeLayer(you);
						
					},
				success: function(data){
					var i=0;
					$("#loading_map").css("display","none");
					frndsIcon = L.icon({
						iconUrl: 'icon_content/frndss-min.png',
						iconSize:     [30,30], // size of the icon
						
											});
					$.each(data,function(index, element){
								if(i==0)
								   {
									   marker[i]=L.marker([element.lat, element.lon], {icon: frndsIcon}).addTo(map).bindPopup('<center><img src="icon_content/trusting-in-someone.png"  width="80" height="80" lat="'+element.lat+'" lng="'+element.lon+'" id="mapicon" iconsrc="icon_content/men-and-women-toilet.png"/><br><div class="frnds_">'+element.name+'<br>(YOU)</div></center>');
								   }
								else
									{
										marker[i]=L.marker([element.lat, element.lon], {icon: frndsIcon}).addTo(map).bindPopup('<center><img src="icon_content/trusting-in-someone.png"  width="80" height="80" lat="'+element.lat+'" lng="'+element.lon+'" id="mapicon" iconsrc="icon_content/men-and-women-toilet.png"/><br><br><button onclick="lme()" class="btn_locate">Route-Me</button><br><div class="frnds_">'+element.name+'</div></center>');
									}
						i++;
					});
					
				}
		});
	}
	else
	 {
		alert('You have not upload your friends data yet. Please upload it first.');
	 }
}
